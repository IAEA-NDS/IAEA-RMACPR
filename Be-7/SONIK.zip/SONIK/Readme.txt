From:	Paneru, Som Nath <paneru@lanl.gov>
Sent:	Wednesday, November 20, 2024 10:32 PM
To:	DIMITRIOU, Paraskevi
Subject:	SONIK data
Attachments:	data_SONIK(2).tar

CAUTION: This email originated from outside of the organization. Do not click links or open attachments unless you 
recognize the sender and know the content is safe.

Dear Vivian,

The SONIK data for 3He+4He elastic scattering is attached. There are 10 data files in the 
folder corresponding to different incident beam energies. The files are already in AZURE2 
format meaning the cross sections are reported such that it is always 3He incident on 4He.
The columns for the tables are as follows:
E(3He) theta cs(barns) ecs(barns)

In each file, you will see three different energy groupings, which corresponds to the 
effective energy at 3 interaction regions in SONIK for a given incident 3He beam energy. 
Refer to the dissertation and the PRC article for further details.
1.	https://www.proquest.com/docview/2582223697?pq-
origsite=gscholar&fromopenview=true&sourcetype=Dissertations%20&%20Theses
2.	https://journals.aps.org/prc/abstract/10.1103/PhysRevC.109.015802
Let me know if anyone have any questions regarding the data. Thank you.


Regards,
Som Nath Paneru
Postdoctoral Research Associate
Nuclear and Particle Physics and Applications, P-3
Los Alamos National Laboratory
Work: +1-505-667-5619



